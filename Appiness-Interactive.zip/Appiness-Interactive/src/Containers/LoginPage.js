import React from 'react';
import * as Images from '../images/img-01.png';
import Div from '../Components/Div';
import Img from '../Components/Img';
import Span from '../Components/Span';
import Input from '../Components/Input';
import Button from '../Components/Button';
import A from '../Components/A';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import { bindActionCreators } from 'redux';
import {UserNameChange,PasswordChange} from '../Actions/LoginActions';
import { useHistory } from "react-router-dom";
import {ShowNotification} from '../notification';

export function LoginPage(props){
	const history=useHistory();
	let Login=(userName,password)=>{
		let emailRegex=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(!emailRegex.test(userName)&&userName!=null){
			ShowNotification("E","Entered Email is invalid");
			return false;
		}
		if(userName==null||password==null){
			ShowNotification("W","Username and password cannot be null");
			return false;
		}
		else{
			if(userName===props.loginData.username&&password===props.loginData.password){
				history.push('/EmployeeList');
			}
			else{
				ShowNotification("E","Credentials does not match");
				return false;
			}
		}
	}
    return (
		<Div>
			<Helmet>
				<meta name="EmployeeList" content="Employee List" />
			</Helmet>
        <Div classes="limiter">
		<Div classes="container-login100">
			<Div classes="wrap-login100">
				<Div classes="login100-pic">
					<Img classes="login100-picimg" src={Images} alt="IMG"/>
				</Div>

				<Div classes="login100-form">
					<Span classes="login100-form-title">
						Login
					</Span>

					<Div classes="wrap-input100">
						<Input classes="input100" type="text" name="email" placeholder="Email" onChange={e=>props.UserNameChange(e.target.value)}/>
						<Span classes="focus-input100"></Span>
						<Span classes="symbol-input100">
							<i class="fa fa-envelope"></i>
						</Span>
					</Div>

					<Div classes="wrap-input100">
						<Input classes="input100" type="password" name="pass" placeholder="Password"  onChange={e=>props.PasswordChange(e.target.value)}/>
						<Span classes="focus-input100"></Span>
						<Span classes="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</Span>
					</Div>
					
					<Div classes="container-login100-form-btn">
						<Button classes="login100-form-btn" onClick={()=>Login(props.userName,props.password)}>
							Login
						</Button>
					</Div>

					<Div classes="textcenterpt12">
					
					</Div>

					<Div classes="textcenterpt136">
						<A classes="txt2" href="#">
							
						</A>
					</Div>
				</Div>
			</Div>
		</Div>
	</Div>
	</Div>
    );
}

function mapStateToProps(storeData) {
    return {
		userName:storeData.userName,
		password:storeData.password,
		loginData:storeData.loginData,
    };
}

function matchDispatcherToProps(dispatch) {
    return bindActionCreators({       
		UserNameChange:UserNameChange,
		PasswordChange:PasswordChange,
    }, dispatch);
}

export default connect(mapStateToProps, matchDispatcherToProps)(LoginPage);