import React,{useState} from 'react';
import { useHistory } from "react-router-dom";
import Div from '../Components/Div';
import Table from '../Components/Table';
import Span from '../Components/Span';
import Thead from '../Components/Thead';
import Tbody from '../Components/Tbody';
import Th from '../Components/Th';
import Tr from '../Components/Tr';
import Li from '../Components/Li';
import I from '../Components/I';
import Helmet from 'react-helmet';
import Td from '../Components/Td';
import P from '../Components/P';
import Ul from '../Components/Ul';
import * as UserIcon from '../images/@user.png';
import Img from '../Components/Img';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

export function EmployeeList(props){
    const headerKeys=Object.keys(props.gridData.user[0]);
    let [displayFlag,setdisplayFlag]=useState(false);
    const history= useHistory();
    let Logout=()=>{
        history.push('/');
    }
    let flagSet=()=>{
        setdisplayFlag(!displayFlag);
    }
    let TrBinder=(TableData)=>{
        let TrData=[];
        for(let m=0;m<TableData.length;m+=1){
            let TdData=[];
            for(let n=0;n<headerKeys.length;n+=1){
                TdData.push(<Td classes="cell100">{TableData[m][headerKeys[n]]}</Td>);
            }
            TrData.push(<Tr classes="row100">{TdData}</Tr>);
        }
        return TrData;
    }
    return (
        <Div>
        <Helmet>
             <meta name="EmployeeList" content="Employee List" />
        </Helmet>
        <Div classes="header">
            <P>Employee List</P>
            <Img src={UserIcon} classes="UserIcon" onClick={()=>flagSet()}></Img>
            {displayFlag==true&&
            <Ul classes="hd-menu">
                                            <Li className="user dropdown">
                                                    <a> 
                                                            
                                                                <Span><I className="fa fa-user" classes="userIcon"></I>{props.loginData.username}</Span> 
                                                            
                                                    </a>
                                            </Li>
                                            <Li classes="Dropdown" onClick={()=>Logout()}><I clasName="fas fa-sign-in-alt"></I>Logout</Li>
            </Ul>
        }
        </Div>
        <Div classes="GridLimiter">
		    <Div classes="container-table100">
			    <Div classes="wrap-table100">
                    <Div classes="table100-ver3">
					    <Div classes="table100-head">
						<Table>
							<Thead>
								<Tr>
									{headerKeys.map(each=>
                                    <Th classes="cell100">{each}</Th>
                                    )}
								</Tr>
							</Thead>
						</Table>
					</Div>

					<Div classes="table100-body">
						<Table>
							<Tbody>
								{TrBinder(props.gridData.user)}
							</Tbody>
						</Table>
                        <Div classes="ps__rail-y">
                            <Div classes="ps__thumb-y" tabindex="0">
                            </Div>
                        </Div>
					</Div>
				</Div>
            </Div>
        </Div>
    </Div>
<Div classes="footer">
  <P>Thanks for Visiting!!</P>
</Div>
</Div>
    );
}



function mapStateToProps(storeData) {
    return {
        gridData:storeData.gridData,
        loginData:storeData.loginData,
    };
}

function matchDispatcherToProps(dispatch) {
    return bindActionCreators({       
    }, dispatch);
}

export default connect(mapStateToProps, matchDispatcherToProps)(EmployeeList);
