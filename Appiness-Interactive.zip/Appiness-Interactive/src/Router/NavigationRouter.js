import LoginPage from '../Containers/LoginPage';
import EmployeeList from '../Containers/EmployeeList';
import { Route,Router } from 'react-router-dom';
import React from 'react';
import { Provider } from 'react-redux';
import configureStore from '../Stores/ConfigureStore';
import { createBrowserHistory } from "history";
const customHistory = createBrowserHistory();
const store = configureStore();

function NavigationRouter(props) {
    return (
        <Provider store={store}>
            <Router history={customHistory}> 
              <Route exact path="/" component={LoginPage}/>
              <Route exact path="/EmployeeList" component={EmployeeList}/>
            </Router>
        </Provider>
    );
  }
  
  export default NavigationRouter;

