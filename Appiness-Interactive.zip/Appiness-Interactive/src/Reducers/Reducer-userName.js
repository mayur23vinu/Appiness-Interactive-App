import * as ActionTypes from '../Constants/ActionTypes';

export default function(state = null, action) {
    switch(action.type) {
        case ActionTypes.CHANGE_USERNAME: 
            return action.payload;
        default : 
            return state;
    }
}