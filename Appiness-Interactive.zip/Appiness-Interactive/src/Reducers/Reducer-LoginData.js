import * as ActionTypes from '../Constants/ActionTypes';

export default function(state = {
    "username":"hruday@gmail.com",
    "password" :'hruday123'
    }, action) {
    switch(action.type) {
        case ActionTypes.LOGIN_DATA: 
            return action.payload;
        default : 
            return state;
    }
}