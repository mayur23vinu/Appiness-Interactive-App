import { combineReducers } from 'redux';
import userNameReducer from '../Reducers/Reducer-userName';
import passwordReducer from '../Reducers/Reducer-password';
import loginDataReducer from '../Reducers/Reducer-LoginData';
import GridDataReducer from '../Reducers/Reducer-GridData';

const MasterReducer = combineReducers({
    userName:userNameReducer,
    password:passwordReducer,
    loginData:loginDataReducer,
    gridData:GridDataReducer,
});

export default MasterReducer;