import React from 'react';
import Div from '../components/Div';
import Span from '../components/Span';
import I from '../components/I';
import history from '../utils/history';
import Select from  '../components/Select'
import Option from  '../components/Option';
import Label from '../components/Label';
import Li from '../components/Li';
import timezoneNames from 'timezone-names';
import dateformat from 'dateformat';
import {authContext} from 'configs/adalConfig';
import { ShowNotification } from '../notification';

// function to render fields wrt to controlType

const renderFields = (subRegion, data) => {
  const fields = subRegion.fieldSetup;
    return(
      <Div classes={`${subRegion.regionName}`} className="row">
                {Array.isArray(fields) && fields.length && fields.map((field) => {
                 const fieldArray = data.dynamic.filter(item=>item.regionId === subRegion.regionId && item.regionData.fieldId === field.fieldId).map(arr=>arr.regionData.fieldValue)
                 return field.controlType === 'dropDown'? (
                  <Div className="col-md-2" classes="no_padding">
                    <Div classes="request_item">
                      <Label classes="request_label">{`${field.fieldName}`}</Label>
                      <Select classes="select_status" >
                        {field.valueList.map((option)=><Option>{option.value}</Option>)}
                      </Select>
                    </Div>
                   </Div>
                 )
                 :
                 (
                  <>
                   <Li classes="request_status" className="col-md-3">
                    <Span classes={`${field.fieldType}`}>
                      {`${field.fieldName}:`}
                    </Span>
                    <Span classes={`${field.fieldType}_value`}>
                      {`  ${fieldArray[0]}`}
                    </Span>
                   </Li>
                  </>
                )})}
              </Div>
    );
}

//function to render regions->subRegions->fields

export const regionRenderer =(regions, data, screenName) =>{
    const icon = data.static.requestStatus.icon;
    const requestStatus = data.static.requestStatus.requestStatusName;
    const attachmentCount = data.static.attachmentCount;
    return Array.isArray(regions) &&
    regions.length &&
    regions.map((region, index) => {
      const subRegions = region.regionSetup;
       return region.regionType === 'Div' && (
        <Div key={index} onClick = {(e)=>{gotoRequestPage(e,screenName)}} classes={`${region.regionName}_${requestStatus}`}>
          <Span>
            <I
              className={`${icon}`}
              classes="icon-arrow"
            />
          </Span>
          <Span classes="request_staus_region">{requestStatus}</Span>
          {Array.isArray(subRegions) && subRegions.length && subRegions.map(subRegion => {
             return renderFields(subRegion, data);
          })}
          {screenName === 'RequestDashboard' && (
            <>
              <Div classes="request_header-lastpart">
                <I className="fal fa-paperclip" classes="icon-attach" />{' '}
                <Span classes="attachmnt-count">{attachmentCount} attachment(s)</Span>
              </Div>
              <Div classes="circle_icon">
                <Span classes="circle_tat" />
              </Div>
            </>
          )}
        </Div>
      );
    })
}

export default function TimeCalculator(UTCTime) {
  let TimeOffset=((new Date().getTimezoneOffset()));
  let Timezone=getTimezoneName();
  if(Timezone.Abbreviation!=undefined){
    Timezone=Timezone.Abbreviation;
  }
  else{
    Timezone=Timezone.split(' ');
    const TimezoneAbbr = Timezone.map((each) => each[0]).join('');
    Array.isArray(Timezone)==true?Timezone=TimezoneAbbr:Timezone;
  }
  let UTCTimeasDate=new Date(UTCTime);
  let TimeOffsetinHours=TimeOffset/60;
  let Sign=Math.sign(TimeOffset);
  if(Sign==-1){
    UTCTimeasDate.setHours(UTCTimeasDate.getHours()-Math.ceil(TimeOffsetinHours));
    UTCTimeasDate.setMinutes(UTCTimeasDate.getMinutes()-((TimeOffsetinHours-Math.ceil(TimeOffsetinHours))*60));
  }
  else if(Sign==+1){
    UTCTimeasDate.setHours(UTCTimeasDate.getHours()+Math.floor(TimeOffsetinHours));
    UTCTimeasDate.setMinutes(UTCTimeasDate.getMinutes()+((TimeOffsetinHours-Math.floor(TimeOffsetinHours))*60));
  }
  else{
    UTCTimeasDate=UTCTimeasDate;
  }
  let finaltimeStamp=(dateformat(UTCTimeasDate).toString())+' '+Timezone;
  return finaltimeStamp;
}

function getTimezoneName() {
  const today = new Date();
  const short = today.toLocaleDateString(undefined);
  const full = today.toLocaleDateString(undefined, { timeZoneName: 'long' });
  const shortIndex = full.indexOf(short);
  if (shortIndex >= 0) {
    const trimmed = full.substring(0, shortIndex) + full.substring(shortIndex + short.length);
    const timezoneName=trimmed.replace(/^[\s,.\-:;]+|[\s,.\-:;]+$/g, '');
    const timezoneNameabbr=timezoneNames.getTimezoneByName(timezoneName);
    if(timezoneNameabbr!==undefined){
      return timezoneNameabbr;
    }
    else{
      return timezoneName;
    }

  } else {
    return full;
  }
}

export function useErrorHandler(err){
  const response = err.response;

  if(response && response.status === 401){
    sessionStorage.clear();
    authContext.logOut();
    ShowNotification('W', 'You have been logged out due to session Timeout. Please log in to continue');
  }
  else if(response && response.status === 504){
    ShowNotification('W', 'Timeout occurred. Please try again!');
  }
  else{
    ShowNotification('E', 'There was an Error');
  }
}