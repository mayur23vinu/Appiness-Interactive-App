import { notification } from 'antd';

export function ShowNotification(type, status, msg) {
  switch (type) {
    case 'S':
      notification.success({
        message: status,
        description: msg,
        duration: 3,
      });
      break;
    case 'W':
      notification.warning({
        message: status,
        description: msg,
        duration: 3,
      });
      break;
    case 'E':
      notification.error({
        message: status,
        description: msg,
        duration: 3,
      });
      break;
    default:
      notification.info({
        message: status,
        description: msg,
        duration: 3,
      });
      break;
  }
}
