import styled from 'styled-components';

const A = styled.a`
  ${props => {
    switch (props.classes){
        case 'txt2':
            return {
                fontFamily: 'Poppins-Regular',
                fontSize: '13px',
                lineHeight: 1.5,
                color: '#666666',
            }
        default:
                return {};
        }
    }
}}};
`;

export default A;