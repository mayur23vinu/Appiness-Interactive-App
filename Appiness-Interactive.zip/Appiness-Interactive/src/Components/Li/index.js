import styled from 'styled-components';

const Li = styled.li`
  ${props => {
    switch (props.classes){
            case 'Dropdown':
                return {                   
                    float: 'left',
                    clear: 'both',
                    width: '100%',
                    color:'black',
                }
            default:
                return {};
        }
    }
}}};
`;

export default Li;