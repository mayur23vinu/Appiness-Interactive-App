import styled from 'styled-components';

const Div = styled.div`
  ${props => {
    switch (props.classes){
        case 'limiter':
            return {
                width: '100%',
            }
        case 'container-login100':
            return {
                width: '100%',  
                minHeight: '100vh',
                margin:'0px',
                boxSizing:'border-box',
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignItems: 'center',
                padding: '15px',
                background: 'linear-gradient(-135deg, #c850c0, #4158d0)',
            }
        case 'wrap-login100':
            return {
                width: '960px',
                background: '#fff',
                margin:'0px',
                boxSizing:'border-box',
                borderRadius: '10px',
                overflow: 'hidden',
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                padding: '177px 130px 33px 95px'
            }
        case 'login100-pic':
            return {
                width: '316px',
                willChange: 'transform',
                transform: 'perspective(300px) rotateX(0deg) rotateY(0deg)',
            }
        case 'wrap-input100':
            return{
                position: 'relative',
                width: '100%',
                zIndex: '1',
                marginBottom: '10px',
            }
        case 'container-login100-form-btn':
            return{
                width: '100%',
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                paddingTop: '20px'
            }
        case 'GridLimiter':
            return {
                width: '1366px',
                margin: '0 auto',
            }
        case 'container-table100':
            return {
                width: '100%',
                minHeight: '100vh',
                background: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexWrap: 'wrap',
                padding: '33px 30px'
            }
        case 'table100-ver3':
            return {
                borderRadius: '10px',
                overflow: 'hidden',
                backgroundColor: '#393939',
                boxShadow: '0 0px 40px 0px rgba(0, 0, 0, 0.15)',
                position: 'relative',
                paddingTop: '60px',
                marginBottom: '110px'
            }
        case 'header':
            return {
                    padding: '10px 16px',
                    background: '#555',
                    color: '#00ad5f',
                    fontWeight:300,
            }
        case 'footer':
            return {
                position: 'fixed',
                left: 0,
                bottom: 0,
                width: '100%',
                backgroundColor: '#393939',
                color:'#00ad5f',
                textAlign: 'center',
                paddingTop: '8px',
            }
        case 'table100-body':
            return{
                maxHeight: '585px',
                position: 'relative',
                overflow: 'hidden !important',
                overflowAnchor: 'none',
                touchAction: 'auto',
            }
        case 'table100-head':
            return {
                position: 'absolute',
                width: '100%',
                top: 0,
                left: 0,
            }
        case 'wrap-table100':
            return {
                width: '1170px',
            }
        case 'login100-form':
            return {
                width: '290px',
            }
        case 'textcenterpt12':
            return {
                textAlign:'center!important',
                paddingTop:'12px',
            }
        case 'textcenterpt136':
            return {
                textAlign:'center!important',
                paddingTop:'136px',
            }
        default:
            return {};
    }
}
}}};
`;

export default Div;
