import styled from 'styled-components';

const Th = styled.th`
  ${props => {
    switch (props.classes){
        case 'cell100':
            return {
                fontFamily: 'Lato-Bold',
                fontSize: '15px',
                color: '#00ad5f',
                lineHeight: '1.4',
                textTransform: 'uppercase',
                backgroundColor: '#393939',
                paddingTop: '18px',
                paddingBottom: '18px',
                fontWeight: 'unset',
                paddingRight: '10px',
                textAlign: 'left',
                width:'20%',
                paddingLeft:'22px',
            }
            default:
                return {};
        }
    }
    }}};
    `;

export default Th;