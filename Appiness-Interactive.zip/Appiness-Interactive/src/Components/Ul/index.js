import styled from 'styled-components';

const Ul = styled.ul`
  ${props => {
    switch (props.classes){
            case 'dropdown-menu':
                return {
                    maxHeight: '330px',
                };
            case 'hd-menu':
                return {
                    border: '1px solid #555555',
                    background: 'white',
                    width: '14%',
                    right: '0px',
                    position: 'absolute',
                    top: '55px',
                    padding: '5px',
                    listStyleType: 'none'
                }
            default:
                return {
                    width: '100%',
                };
        }
    }
    }}};
    `;

export default Ul;