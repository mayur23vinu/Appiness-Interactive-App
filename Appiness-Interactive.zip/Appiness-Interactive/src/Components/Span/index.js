import styled from 'styled-components';

const Span = styled.span`
  ${props => {
    switch (props.classes){
        case 'login100-form-title':
            return{
                fontFamily: 'Poppins-Bold',
                fontSize: '24px',
                color: '#333333',
                lineHeight: '1.2',
                textAlign: 'center',
                width: '100%',
                display: 'block',
                paddingBottom: '54px',
            };
        case 'txt1':
            return {
                fontFamily: 'Poppins-Regular',
                fontSize: '13px',
                lineHeight: '1.5',
                color: '#999999',
            };
        case 'symbol-input100':
            return {
                fontSize: '15px',  
                display: 'flex',
                alignItems: 'center',
                position: 'absolute',
                borderRadius: '25px',
                bottom: 0,
                left: 0,
                width: '100%',
                height: '100%',
                paddingLeft: '35px',
                pointerEvents: 'none',
                color: '#666666',
                '-webkit-transition': 'all 0.4s',
                '-o-transition': 'all 0.4s',
                '-moz-transition': 'all 0.4s',
                'transition': 'all 0.4s',
            }
        case 'focus-input100':
            return {
                display: 'block',
                position: 'absolute',
                borderRadius: '25px',
                bottom: 0,
                left: 0,
                zIndex: -1,
                width: '100%',
                height: '100%',
                boxShadow: '0px 0px 0px 0px',
                color: 'rgba(87,184,70, 0.8)',
            }
            default:
                return {};
        }
    }
    }}};
    `;

export default Span;