import styled from 'styled-components';

const Table = styled.table`
  ${props => {
    switch (props.classes){
            default:
                return {
                    width: '100%',
                    borderCollapse:'collapse'
                };
        }
    }
    }}};
    `;

export default Table;