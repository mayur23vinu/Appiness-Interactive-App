import styled from 'styled-components';

const Img = styled.img`
  ${props => {
    switch (props.classes){
        case 'login100-picimg':
            return{
                maxWidth: '100%',
                verticalAlign: 'middle',
                borderStyle: 'none',
            }
        case 'UserIcon':
            return {
                float: 'right',
                position: 'relative',
                marginTop: '-40px',
            }
        default:
            return {};
    }
}
}}};
`;

export default Img;