import styled from 'styled-components';

const Thead = styled.thead`
  ${props => {
    switch (props.classes){
            default:
                return {
                    width: '100%',
                };
        }
    }
    }}};
    `;

export default Thead;