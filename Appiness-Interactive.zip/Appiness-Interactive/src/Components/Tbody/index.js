import styled from 'styled-components';

const Tbody = styled.tbody`
  ${props => {
    switch (props.classes){
            default:
                return {
                };
        }
    }
    }}};
    `;

export default Tbody;