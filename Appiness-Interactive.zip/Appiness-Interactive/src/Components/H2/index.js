import styled from 'styled-components';

const H2 = styled.h2`
  ${props => {
    switch (props.classes){
            default:
                return {};
        }
    }
}}};
`;

export default H2;