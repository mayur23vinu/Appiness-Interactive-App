import styled from 'styled-components';

const P = styled.p`
  ${props => {
    switch (props.classes){
            default:
                return {};
        }
    }
}}};
`;

export default P;