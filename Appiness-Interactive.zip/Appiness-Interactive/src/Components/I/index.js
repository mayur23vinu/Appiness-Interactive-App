import styled from 'styled-components';

const I = styled.i`
  ${props => {
    switch (props.classes){
            case 'userIcon':
                return {                   
                    paddingRight: '12px',
                    paddingLeft: '5px'
                }
            default:
                return {};
        }
    }
}}};
`;

export default I;