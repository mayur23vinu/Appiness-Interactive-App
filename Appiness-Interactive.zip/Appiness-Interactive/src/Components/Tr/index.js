import styled from 'styled-components';

const Tr = styled.tr`
  ${props => {
    switch (props.classes){
            default:
                return {};
        }
    }
    }}};
    `;

export default Tr;