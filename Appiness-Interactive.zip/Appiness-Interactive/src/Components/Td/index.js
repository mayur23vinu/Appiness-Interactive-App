import styled from 'styled-components';

const Td = styled.td`
  ${props => {
    switch (props.classes){
        case 'cell100':
            return {
                fontFamily: 'Lato-Regular',
                fontSize: '15px',
                color: '#808080',
                lineHeight: '1.4',
                backgroundColor: '#222222',
                paddingTop: '16px',
                paddingBottom: '16px',
                width:'18%',
                paddingLeft: '25px',
            }
            default:
                return {};
        }
    }
    }}};
    `;

export default Td;