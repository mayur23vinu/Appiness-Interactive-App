import styled from 'styled-components';

const Form = styled.form`
  ${props => {
    switch (props.classes){
            default:
                return {};
        }
    }
}}};
`;

export default Form;