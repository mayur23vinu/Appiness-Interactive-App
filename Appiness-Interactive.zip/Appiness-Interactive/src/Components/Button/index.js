import styled from 'styled-components';

const Button = styled.button`
  ${props => {
    switch (props.classes){
        case 'login100-form-btn':
            return {
                fontFamily: 'Montserrat-Bold',
                outline: 'none !important',
                border: 'none',
                fontSize: '15px',
                lineHeight: 1.5,
                color: '#fff',
                textTransform: 'uppercase',
                width: '100%',
                height: '50px',
                borderRadius: '25px',
                background: '#57b846',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                padding: '0 25px',
                '-webkit-transition': 'all 0.4s',
                '-o-transition': 'all 0.4s',
                '-moz-transition': 'all 0.4s',
                'transition': 'all 0.4s',
            }
            default:
                return {};
    }
}
}}};
`;

export default Button;