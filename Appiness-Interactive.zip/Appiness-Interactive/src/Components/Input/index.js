import styled from 'styled-components';

const Input = styled.input`
  ${props => {
    switch (props.classes){
        case 'input100':
            return {
                fontFamily: 'Poppins-Medium',
                fontSize: '15px',
                lineHeight: '1.5',
                color: '#666666',
                display: 'block',
                width: '100%',
                background: '#e6e6e6',
                height: '50px',
                borderRadius: '25px',
                padding: '0 30px 0 68px',
                outline:'none',
                border:'none',
                overflow:'visible',
            }
            default:
                return {};
    }
}
}}};
`;

export default Input;