import * as ActionTypes from '../Constants/ActionTypes';

export const UserNameChange=userName=>
({
    type: ActionTypes.CHANGE_USERNAME,
    payload:userName
  });

  export const PasswordChange=password=>
  ({
    type: ActionTypes.CHANGE_PASSWORD,
    payload:password
  });